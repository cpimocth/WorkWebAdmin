CPI Price Entry Web V3 - ชุด Import Master + Supabase

ไฟล์หลัก
1. index.html - เว็บ V3 ล่าสุด (มีตัวกรอง CODE7, Supabase config ฝังไว้, GeoMean 5 ตำแหน่ง)
2. CPI_Master_Import_V3_100_Examples.xlsx - Master ตัวอย่าง 100 แถว พร้อม CODE7 7 หลัก
3. supabase_upgrade_v3.sql - อัปเกรด/สร้างฐาน โดยเก็บข้อมูลเดิม
4. supabase_reset_v3.sql - ล้าง price_master + monthly_prices แล้วสร้างใหม่ทั้งหมด (ข้อมูลเดิมหาย)

แนะนำถ้ามีฐานเดิมแล้ว: Run supabase_upgrade_v3.sql เท่านั้น
ถ้ากำลังทดลองและอยากล้างทั้งหมด: Run supabase_reset_v3.sql

การ Import Master
- Login เว็บ
- กด Import Master
- เลือก CPI_Master_Import_V3_100_Examples.xlsx
- เว็บอ่านชีทแรก Master_Import
- Key การ Upsert = COMMODITY_CODE 16 หลัก + DILLER_CODE 10 หลัก
- CODE7 ต้อง 7 หลักและตรงกับ 7 ตัวแรกของ COMMODITY_CODE
